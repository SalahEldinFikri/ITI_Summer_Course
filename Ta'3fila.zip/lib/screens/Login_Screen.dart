import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:helloworld/screens/Forgot.dart';
import 'package:helloworld/screens/home_screen.dart';
import 'package:helloworld/screens/noaccount.dart';
import 'package:shared_preferences/shared_preferences.dart';

class loginscreen extends StatefulWidget {
  const loginscreen({Key? key}) : super(key: key);

  @override
  State<loginscreen> createState() => _loginscreenstate();
}

class _loginscreenstate extends State<loginscreen> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailcontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
      ),
      backgroundColor: Colors.white,
      body: Center(
        key: _formKey,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 25.0),
            ),
            Image(image: AssetImage('assets/images.jpg')),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 15.0),
            ),
            TextFormField(
              controller: emailcontroller,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              decoration: const InputDecoration(
                hintText: 'Enter your email',
              ),
              validator: (String? value) {
                if (value == null || value.contains("@") == false) {
                  return 'Please enter valid Email';
                }
                return null;
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5.0),
            ),
            TextFormField(
              autovalidateMode: AutovalidateMode.onUserInteraction,
              decoration: const InputDecoration(
                hintText: 'Enter your password',
              ),
              validator: (String? value) {
                if (value == null || value.length < 6) {
                  return 'Please Enter your password';
                }
                return null;
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: ElevatedButton(
                child: const Text('Login'),
                onPressed: () async {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => HomeScreen(
                              emails: emailcontroller.text,
                            )),
                  );
                  if (_formKey.currentState!.validate()) {
                    final SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    await prefs.setString('email', emailcontroller.text);

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Success"),
                      ),
                    );
                  }
                },
              ),
            ),
            RichText(
              text: TextSpan(children: [
                TextSpan(
                  text: 'Forgot password?  ',
                  style: TextStyle(
                    color: Colors.black,
                  ),
                ),
                TextSpan(
                    text: 'Press here',
                    style: TextStyle(
                      color: Colors.blue,
                    ),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => forgot()),
                        );
                      }),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => account()),
                  );
                  // the form is invalid.
                },
                child: const Text('No Account? Sgin Up'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _formKey {}
