import 'package:flutter/material.dart';
import 'package:helloworld/screens/profile.dart';
import 'package:helloworld/screens/settings.dart';
import 'package:helloworld/screens/library.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeScreen extends StatefulWidget {
  String emails;
  HomeScreen({super.key, required this.emails});

  @override
  State<HomeScreen> createState() => _HomeScreenstate();
}

class _HomeScreenstate extends State<HomeScreen> {
  int cindex = 0;
  String email = '';

  List<Widget> pages = [
    profile(),
    settings(),
    Library(),
  ];
  @override
  Widget build(BuildContext context) {
    var scaffold = Scaffold(
      body: pages[cindex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: cindex,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "profile"),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings), label: "settings"),
          BottomNavigationBarItem(
              icon: Icon(Icons.library_add), label: "Library"),
        ],
        onTap: (value) {
          cindex = value;
          setState(() {});
          print(value);
        },
      ),
    );
    return scaffold;
  }
}
