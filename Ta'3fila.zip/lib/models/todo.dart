class Usermodel {
  int? userId;
  int? id;
  String? title;
  bool? completed;

  Usermodel({
    this.userId,
    this.id,
    this.title,
    this.completed,
  });

  factory Usermodel.fromJson(Map<String, dynamic> json) => Usermodel(
        userId: json["userId"],
        id: json["id"],
        title: json["title"],
        completed: json["completed"],
      );

  Map<String, dynamic> toJson() => {
        "userId": userId,
        "id": id,
        "title": title,
        "completed": completed,
      };
}
