import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:helloworld/models/usermodel.dart';

class UserService {
  String url = "https://jsonplaceholder.typicode.com/todos";
  Future<List<Usermodel>> getUsers() async {
    List<Usermodel> userlist = [];
    final dio = Dio();

    final response = await Dio().get(url);
    print(response);

    var data = response.data;
    data.forEach((element) {
      Usermodel user = Usermodel.fromJson(element);
      userlist.add(user);
    });

    return userlist;
  }
}
