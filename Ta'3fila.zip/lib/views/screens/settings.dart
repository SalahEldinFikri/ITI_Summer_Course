import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:helloworld/models/usermodel.dart';
import 'package:helloworld/services/user_service.dart';

import '../cubit/todo_cubit.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => TodoCubit(),
      child: BlocConsumer<TodoCubit, TodoState>(
        listener: (context, state) {},
        builder: (context, state) {
          if (state is TodoLoading) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          if (state is TodoError) {
            return Center(
              child: Text("Error"),
            );
          }
          return ListView.builder(
              itemCount: (context).watch<TodoCubit>().todo.length,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                    leading: Text("${index + 1}"),
                    title: Text(
                        (context).watch<TodoCubit>().todo[index].title ?? "--"),
                    trailing: Text((context)
                        .watch<TodoCubit>()
                        .todo[index]
                        .completed
                        .toString()));
              });
        },
      ),
    );
  }
}
