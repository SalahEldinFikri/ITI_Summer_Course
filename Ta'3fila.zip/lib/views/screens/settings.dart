import 'dart:async';
import 'package:flutter/material.dart';
import 'package:helloworld/models/usermodel.dart';
import 'package:helloworld/services/user_service.dart';

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  List<Usermodel> user = [];
  bool isloading = true;

  Future<void> getuser() async {
    user = await UserService().getUsers();
    setState(() {
      isloading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    getuser();
  }

  @override
  Widget build(BuildContext context) {
    return isloading
        ? Center(
            child: CircularProgressIndicator(),
          )
        : ListView.builder(
            itemCount: user.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(user[index].userId.toString()),
                    Text(user[index].title ?? '--'),
                  ],
                ),
                subtitle: Text(user[index].id.toString()),
                trailing: Icon(Icons.person),
                leading: Text("${index + 1}"),
              );
            },
          );
  }
}
