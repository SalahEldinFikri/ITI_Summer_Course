import 'dart:async';
import 'package:flutter/material.dart';
import 'package:helloworld/models/usermodel.dart';
import 'package:helloworld/services/user_service.dart';

class settings extends StatefulWidget {
  const settings({super.key});

  @override
  State<settings> createState() => _settingsState();
}

class _settingsState extends State<settings> {
  List<Usermodel> user = [];
  bool isloading = true;

  getuser() async {
    user = await UserService().getUsers();
    isloading = false;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getuser();
  }

  @override
  Widget build(BuildContext context) {
    return isloading
        ? Center(
            child: CircularProgressIndicator(),
          )
        : ListView.builder(
            itemCount: user.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Text(user[index].name ?? '--'),
                subtitle: Text(user[index].email ?? '--'),
                trailing: Icon(Icons.person),
                leading: Text("${index + 1}"),
              );
            },
          );
  }
}
