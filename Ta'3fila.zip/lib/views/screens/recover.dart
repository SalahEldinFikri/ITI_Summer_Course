import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:helloworld/views/screens/Forgot.dart';
import 'package:helloworld/views/screens/Login_Screen.dart';

class recover extends StatefulWidget {
  const recover({Key? key}) : super(key: key);

  @override
  State<recover> createState() => _recoverState();
}

class _recoverState extends State<recover> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Forgot Password?"),
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(Icons.arrow_back_ios_new),
        ),
      ),
      body: Center(
        key: _formKey,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 45.0),
            ),
            TextFormField(
              autovalidateMode: AutovalidateMode.onUserInteraction,
              decoration: const InputDecoration(
                hintText: 'Enter Code',
              ),
              validator: (String? value) {
                if (value == null || value.length < 11) {
                  return null;
                }
                return null;
              },
            ),
            RichText(
              text: TextSpan(children: [
                TextSpan(
                  text: 'Resend?  ',
                  style: TextStyle(
                    color: Colors.black,
                  ),
                ),
                TextSpan(
                    text: 'Press here',
                    style: TextStyle(
                      color: Colors.blue,
                    ),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => forgot()),
                        );
                      }),
              ]),
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 10.0, horizontal: 50),
              child: ElevatedButton(
                child: const Text('Submit'),
                onPressed: () {
                  // Validate will return true if the form is valid, or false if
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => loginscreen()),
                  );
                  if (_formKey.currentState!.validate()) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Success"),
                      ),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
