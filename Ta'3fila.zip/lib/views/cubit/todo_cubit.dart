import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:bloc/bloc.dart';
import 'package:helloworld/models/usermodel.dart';
import 'package:helloworld/services/todo_services.dart';
import 'package:meta/meta.dart';

part 'todo_state.dart';

class TodoCubit extends Cubit<TodoState> {
  TodoCubit() : super(TodoInitial()) {
    getTodo();
  }

  List<TodoModel> todo = [];

  getTodo() async {
    try {
      emit(TodoLoading());
      todo = await TodoService().getTodoService();
      emit(TodoSuccess());
    } catch (e) {
      emit(TodoError());
    }
  }
}
